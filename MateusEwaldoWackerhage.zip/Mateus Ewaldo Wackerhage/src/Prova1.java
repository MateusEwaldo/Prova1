import java.util.Scanner;

public class Prova1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int qtdalunos;
		String professor, materia, sala;
		
		System.out.print("Insira o seu nome: ");
		professor = sc.next(); 
		System.out.print("Insira a mat�ria que voc� leciona: ");
		materia = sc.next(); 
		System.out.print("Qual o nome ou sigla da sala que voc� gostaria de cadastrar as notas? ");
		sala = sc.next(); 
		System.out.print("Qual a quantidade de alunos na sala? ");
		qtdalunos = sc.nextInt(); 
		
		
		
	}
}